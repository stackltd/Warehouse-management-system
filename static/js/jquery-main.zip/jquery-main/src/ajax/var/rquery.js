export var rquery = /\?/;
